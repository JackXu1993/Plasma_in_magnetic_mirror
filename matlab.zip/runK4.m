function [xSol ySol]=runK4(y) 
global XSTART XSTOP H
x = XSTART; 
i=1; xSol(1) = XSTART; ySol(1,:) = y; 
while XSTOP-x> 1e-14 
    i = i + 1; 
    H = min(H,XSTOP - x);
    y=rk(y,x,H,@dEqs); 
    x = x + H; 
    xSol(i) = x; ySol(i,:) = y;
end