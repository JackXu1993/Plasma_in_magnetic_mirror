function magnetic

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%     start,stop,    xi,  yi,  zi,  vxi,  vyi,   vzi,     h
shoot(0.0,  0.00006, 0.0, 0.0, 0.0, 0.0, 150000, 150000, 0.0000001) 
%     you can change the vyi

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%draw the magnetic field and the animation
[x,z] = meshgrid(-2:0.2:2,-2:0.2:2);
y = zeros(21);
w = gq3(@bx,0,2*3.14159,10,x,y,z);
v = zeros(21);
u = gq3(@bz,0,2*3.14159,10,x,y,z);
figure
quiver3(x,z,y,u,w,v);
view(-35,75)
axis([-2 2 -2 2 -0.15 0.15]);
hold on

[xSol, ySol]=runK4([0.0,0.0,0.0,0.0,150000,150000]);
comet3(ySol(:,3),ySol(:,1),ySol(:,2));