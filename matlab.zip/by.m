function yy=by(xxx)
global px py pz
yy=(pz-1).*sin(xxx)./((px.*px+py.*py+(pz-1).*(pz-1)+1-2.*px.*cos(xxx)-2.*py.*sin(xxx)).^1.5)+(pz+1).*sin(xxx)./((px.*px+py.*py+(pz+1).*(pz+1)+1-2.*px.*cos(xxx)-2.*py.*sin(xxx)).^1.5);