function xx=bx(xxx)
global px py pz
xx=(pz-1).*cos(xxx)./((px.*px+py.*py+(pz-1).*(pz-1)+1-2.*px.*cos(xxx)-2.*py.*sin(xxx)).^1.5)+(pz+1).*cos(xxx)./((px.*px+py.*py+(pz+1).*(pz+1)+1-2.*px.*cos(xxx)-2.*py.*sin(xxx)).^1.5);