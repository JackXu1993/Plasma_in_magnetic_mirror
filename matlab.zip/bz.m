function zz=bz(xxx)
global px py pz
zz=(1-px.*cos(xxx)-py.*sin(xxx))./((px.*px+py.*py+(pz-1).*(pz-1)+1-2.*px.*cos(xxx)-2.*py.*sin(xxx)).^1.5)+(1-px.*cos(xxx)-py.*sin(xxx))./((px.*px+py.*py+(pz+1).*(pz+1)+1-2.*px.*cos(xxx)-2.*py.*sin(xxx)).^1.5);