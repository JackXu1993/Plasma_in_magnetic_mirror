function shoot=shoot(start,stop,x1,y1,z1,vx1,vy2,vz3,h) 
global XSTART XSTOP H
XSTART = start; XSTOP = stop; % Range of integration. 
H = h; % Step size. 
x = XSTART;
[xSol, ySol]=runK4([x1 y1 z1 vx1 vy2 vz3]);
plot(xSol,ySol(:,1))
hold on
plot(xSol,ySol(:,2))
plot(xSol,ySol(:,3))
xlabel('t')
ylabel('x(t),y(t)&z(t)')
legend('x(t)','y(t)','z(t)')




