function integral = gq3(func,a,b,n,xx,yy,zz)%xx,yy,zz are the coordinate of the magnetic field you want to calculate  
global px py pz
px=xx;
py=yy;
pz=zz;

h2 = (b-a)./(2.*n);
sq35 = sqrt(0.6);
w1 = 5/9; %wieght, x=+ sqrt(0.6)
w2 = 8/9; %weight, x=0;
x = linspace (a, b, n+1) ;
sum = 0.0;
for i = 1:n
    %x = [x_{i+1}+x_i]/2 + [x_{i+1}-x_i]/2*newx
sum = sum + w1 * func(x(i) + h2 - sq35 * h2);
sum = sum + w2 * func(x(i) + h2);
sum = sum + w1 * func(x(i) + h2 + sq35 * h2 );
end
integral = h2 * sum
